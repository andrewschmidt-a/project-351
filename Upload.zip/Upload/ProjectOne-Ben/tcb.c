#include <header.h>
#include <stdio.h>
#include <sys\alt_stdio.h>
#include <sys\alt_irq.h>
#include <sys\alt_timestamp.h>
#include <sys\alt_alarm.h>

#define MAX 50000						//Adjust this to change the delay in the my_thread

// disable an interrupt
#define DISABLE_INTERRUPTS() { \
asm("wrctl status, zero"); \
}
// enable an interrupt
#define ENABLE_INTERRUPTS() { \
asm("movi et, 1"); \
asm("wrctl status, et"); \
}

/* pretty much our TCB by another name */
struct thread{
	alt_u32 id;
	alt_u32 *stack_address;
	alt_u32 stack_size;
	alt_u32 *stack_pointer;
	alt_u32 state;
	alt_u32 priority;
	alt_u32 runs;
};

/* 						Creates all of our threads 						  */
/* the fact that we hard code this means that we can only have 12 threads */
struct thread threads[12];
alt_u32 current_thread = 0;
extern from_handler;

/* couple of globals that we use to keep track of the prototype_os context */
int first_run = 1;
alt_u32 *main_context;


/* interrupt handler to make sure that we only get interrupted by the correct timer */
int check_interrupt(){
	if(from_handler == 1){
		}
	return from_handler;
}


/* Function to show that the threads are working correctly */
/* 				Given to us by Witty 					   */
void my_thread(alt_u32 thread_id){
	int i, n, j;
	n = (thread_id % 2 == 0)? 10:15;
	for (i = 0; i < n; i++)
	{
		alt_printf("This is message %x of thread # %x.\n", i, thread_id);
		for (j = 0; j < MAX; j++);
	}
}


/* Just a loop to keep us out of the main prototype */
void join_thread(alt_u32 id){
	while(threads[id].state != 2){

	}
}


/* This is for our end state of a thread */
/* Set as the RA in the initialization   */
void destroy_thread(){
	DISABLE_INTERRUPTS();
	threads[current_thread].state = 2;
	ENABLE_INTERRUPTS();
	while(1){
		int i = 0;
		for(i=0; i<2555; i++){

		}
	}
}


/* Initialize all the threads 			*/
/* This is our create threads function  */
void initialize_thread(int num_thread, int priority){

		//Initializing variables in TCB and allocating space
		threads[num_thread].stack_size = 700;
		threads[num_thread].stack_address = malloc(threads[num_thread].stack_size);
		threads[num_thread].stack_pointer = (threads[num_thread].stack_address+threads[num_thread].stack_size-19);
		threads[num_thread].state = 0;
		threads[num_thread].priority=priority;

		//initialize stack
		threads[num_thread].stack_pointer[-1] = threads[num_thread].stack_address+threads[num_thread].stack_size;
		threads[num_thread].stack_pointer[0] = &destroy_thread;
		threads[num_thread].stack_pointer[5] = num_thread;
		threads[num_thread].stack_pointer[18] = &my_thread; //72
		threads[num_thread].stack_pointer[17] = 1;
}



/* 								This is our scheduler 								*/
/* Mainly this handles all of the context switching and the priority alarm setting  */
alt_u32 my_scheduler(alt_u32 sp){//round robin
	from_handler = 0;
	if(first_run == 1){
		main_context = sp;
		first_run =0;
	}

	/* This section of code is for testing to make sure the threads haven't finished */
	int thread_count = 0;
	if(threads[current_thread].state == 1)																//Check to see if thread is in "Running" state
	{
		threads[current_thread].state = 3;																//If so we change the state to paused
		threads[current_thread].stack_pointer = sp;
		//alt_printf("stack pointer_after run thread[%x]: %x\n", current_thread, sp);					//Testing output
		current_thread = (current_thread+1)%12;															//and move on to the next thread
	}
	while(threads[current_thread].state == 2 && thread_count < 12)
	{
		//alt_printf("thread %x is dead\n", current_thread);	//Testing output
		thread_count++;											//This is used to keep track to see how many times we've run through the code
		current_thread = (current_thread+1)%12;					//Move to the next thread
	}

	if(thread_count == 12){ 									// all are dead
		return main_context;
	}
	threads[current_thread].state = 1;  						// set to running


	/* This is for setting the run quantum time */
	int x = 1;
	if(threads[current_thread].priority == 0)
		x = 2;
	if(threads[current_thread].priority == 1)
		x = 1.5;
	reset_alarm(alt_ticks_per_second()*x);
	threads[current_thread].runs++;
	alt_printf("Stack pointer_prerun thread[%x]: %x\n", current_thread,threads[current_thread].stack_pointer);
	alt_printf("Run count: %x\n",threads[current_thread].runs);

	return threads[current_thread].stack_pointer;

}
