#include <header.h>
#define MAINTHREAD 0
#define MAX 2556
struct thread{
	int id;
	int stack_address;
	int stack_size;
	int stack_pointer;
	int state;
	int priority;
	int runs;
};

int numthreads =0;
struct thread threads[12];
//I want to try this with just sending a thread
/*void initialize_thread(thread currentInit)
{
	currentInit.stack_size = 700;
	currentInit.stack_address = malloc(threads[num_thread].stack_size);
	currentInit.stack_pointer = currentInit.stack_address-currentInit.stack_size/2;
	currentInit.state = 0;
	currentInit.priority=0;
}*/

//struct thread threads[12];
void initialize_thread(int num_thread){

		threads[num_thread].stack_size = 700;
		threads[num_thread].stack_address = malloc(threads[num_thread].stack_size);
		threads[num_thread].stack_pointer = threads[num_thread].stack_address-threads[num_thread].stack_size/2;
		threads[num_thread].state = 0;
		threads[num_thread].priority=0;
		threads[num_thread].runs = 0;
}
int current_thread = 0;
int my_scheduler(int sp){//round robin
	/*if(current_thread == 0){
		printf("Zero\n");
	}*/
	threads[current_thread].stack_pointer= sp;
	threads[current_thread].runs++;
	if(threads[current_thread].state = 1)
	{
		alt_printf("test:%x\n",current_thread );
		alt_printf("testing run amount:%x\n",threads[current_thread].runs);
	}
	if(threads[current_thread].state = 0)
			alt_printf("test2:%x\n",current_thread);
	current_thread = (current_thread+1)%12;

	return sp;
}
void destroy_thread(struct thread currentThread){
	currentThread.state = 1;
}
void create_thread(){

}
void mythread_set_priority(){

}

void join_thread(int num_thread){
	while(threads[num_thread].state = 0)
	{
		alt_printf("THIS RAN\n");
		alt_printf("%x\n",threads[num_thread].state);
			//We can leave this as an infinite loop to wait for
			//the process to end.
	}
	//End the thread
	if(threads[num_thread].state = 1)
	{
		alt_printf("TEST2 RAN");
		destroy_thread(threads[num_thread]);
	}
	//And end here and we'll just return to the prototype function
	//Considering that is the main here.
}

void mythread(int T)
{
	int i,j,n;
	n = (threads[T].id % 2 == 0)? 10:15;
	for(i=0;i<n;i++)
	{
		printf("This is message %d of thread #%d.\n",i,threads[T].id);
		for(j= 0;j<MAX;j++);
	}
}
