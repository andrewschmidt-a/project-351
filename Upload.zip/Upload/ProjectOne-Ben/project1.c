/*
 * "Hello World" example.
 *
 * This example prints 'Hello from Nios II' to the STDOUT stream. It runs on
 * the Nios II 'standard', 'full_featured', 'fast', and 'low_cost' example
 * designs. It runs with or without the MicroC/OS-II RTOS and requires a STDOUT
 * device in your system's hardware.
 * The memory footprint of this hosted application is ~69 kbytes by default
 * using the standard reference design.
 *
 * For a reduced footprint version of this template, and an explanation of how
 * to reduce the memory footprint for a given application, see the
 * "small_hello_world" template.
 *
 */

#include <stdio.h>
#include <sys\alt_stdio.h>
#include <sys\alt_irq.h>
#include <sys\alt_timestamp.h>
#include <sys\alt_alarm.h>
#define ALARMTICKS(x) ((alt_ticks_per_second()*(x))/10)
#define QUANTUM_LENGTH 0
#define MAX 2555
#define NUM_THREADS 12
#define MAINTHREAD 0

/* declaration time */
void * mythread_scheduler(void * CONTEXT);
//void mythread();
void mythread_create(void * function);
alt_u32 myinterrup_handler(void * context);

int runQ_size;
int current_thread;

// Note that ALARMTICKS(5) = 1 * 5 / 10 or 0.5 seconds
int main()
{
	current_thread = 0;
	//alt_printf("This is my prototype OS.\n");
	prototype_os();
	return 0;
}
void prototype_os()
{
	// initialize the timer and its interrupt handler

	my_interrupt_handler();
	initialize_alarm();


	int i;
	for(i=0;i<NUM_THREADS;i++){
		//We need to create the threads not just initialize them in here
		initialize_thread(i);
	}
	for(i= 0; i<NUM_THREADS;i++)
	{
		join_thread(i);
	}

	while (1)
	{
		//printf("This is my prototype OS.\n");
		int j;
		// a delay loop is used below. Try adjust the value of MAX
		for (j = 0; j < MAX; j++){

		}
	}
	return ;
}

void doNothing()
{
	//This will be a test function for just testing threads
	for (int j = 0; j < MAX; j++){
	}
}
void * mythread_scheduler(void * CONTEXT){
	//DO ALL THE NECESSARY SETUP.
	runQ_size = 0;
	if(runQ_size > 0)
	{

		//suspend the current thread and schedule a new thread
	}
	else
	{
		alt_printf("interrupted by the DE2 timer!\n");
	}
	//do whatever you need to do
}
alt_u32 myinterrup_handler(void * context)
{
	//Not sure what to do with this right now
	//global_flag=1;
	return ALARMTICKS(QUANTUM_LENGTH);
}
void mythread_create(void * function)
{
	runQ_size++;
	initialize_thread(runQ_size-1);
}
int mythread_set_priority(int threadID, int priority)
{

}
